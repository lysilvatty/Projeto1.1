import { Link } from "wouter";
import { VideoWithDetails } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { formatDuration } from "@/lib/utils";

interface VideoCardProps {
  video: VideoWithDetails;
}

export default function VideoCard({ video }: VideoCardProps) {
  const {
    id,
    title,
    thumbnailUrl,
    price,
    duration,
    professional,
    category,
    averageRating,
    ratingCount
  } = video;

  // Default placeholder images if needed
  const placeholderThumbnail = `https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=800&q=80`;
  const placeholderProfile = `https://images.unsplash.com/photo-1568602471122-7832951cc4c5?auto=format&fit=crop&w=100&q=80`;

  return (
    <Link href={`/video/${id}`}>
      <Card className="group relative overflow-hidden rounded-xl bg-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
        {/* Video Thumbnail with Overlay */}
        <div className="relative aspect-video overflow-hidden">
          <img 
            src={thumbnailUrl || placeholderThumbnail} 
            alt={title} 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          
          {/* Category Badge */}
          <div className="absolute top-3 left-3 flex items-center gap-1">
            <div 
              className="text-white text-xs font-bold px-3 py-1.5 rounded-full backdrop-blur-sm bg-blue-600/90 shadow-md"
            >
              {category.displayName}
            </div>
            
            {price > 0 && (
              <div className="bg-yellow-500 text-black text-xs font-bold px-3 py-1.5 rounded-full backdrop-blur-sm shadow-md">
                Premium
              </div>
            )}
          </div>
          
          {/* Duration Badge */}
          <div className="absolute bottom-3 right-3 bg-black/70 backdrop-blur-sm text-white text-xs px-2.5 py-1.5 rounded-full flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5 mr-1" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
            </svg>
            {formatDuration(duration)}
          </div>
          
          {/* Play Button Overlay */}
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="rounded-full bg-blue-600 p-3 shadow-lg transform transition-transform duration-300 group-hover:scale-110">
              <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="white">
                <polygon points="5 3 19 12 5 21 5 3"/>
              </svg>
            </div>
          </div>
          
          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent opacity-60 group-hover:opacity-70 transition-opacity"></div>
        </div>
        
        {/* Content */}
        <div className="p-5">
          {/* Title and Price */}
          <div className="flex justify-between items-start mb-3">
            <h3 className="font-semibold text-lg text-gray-800 line-clamp-2 leading-tight">{title}</h3>
            {price > 0 && (
              <span className="text-blue-600 font-bold text-lg">
                R$ {price.toFixed(2).replace('.', ',')}
              </span>
            )}
          </div>
          
          {/* Professional Info */}
          <div className="flex items-center mb-3 pb-3 border-b border-gray-100">
            <img 
              src={professional.profileImage || placeholderProfile} 
              alt={`Foto de ${professional.name}`}
              className="w-10 h-10 rounded-full border-2 border-blue-100 mr-3 object-cover"
            />
            <div>
              <p className="text-gray-900 font-medium text-sm">
                {professional.name}
              </p>
              <p className="text-gray-500 text-xs">
                {professional.experience} anos de experiência
              </p>
            </div>
          </div>
          
          {/* Rating and Action */}
          <div className="flex items-center justify-between mt-2">
            <div className="flex items-center">
              <div className="flex items-center text-yellow-500 mr-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
                <span className="ml-1 font-semibold">
                  {averageRating ? averageRating.toFixed(1) : '4.5'}
                </span>
              </div>
              {ratingCount && ratingCount > 0 ? (
                <span className="text-sm text-gray-500">
                  ({ratingCount} avaliações)
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 text-xs font-medium">
                  Novo
                </span>
              )}
            </div>
            
            <div className="rounded-full bg-gray-100 hover:bg-gray-200 transition-colors p-2 group-hover:bg-blue-50 group-hover:text-blue-600">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
              </svg>
            </div>
          </div>
        </div>
      </Card>
    </Link>
  );
}
