import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Vlog, Category, User } from "@shared/schema";

interface VlogCardProps {
  vlog: Vlog;
}

export default function VlogCard({ vlog }: VlogCardProps) {
  // Fetch the category for this vlog
  const { data: category } = useQuery<Category>({
    queryKey: [`/api/categories/${vlog.categoryId}`],
  });

  // Fetch the professional for this vlog
  const { data: professional } = useQuery<User>({
    queryKey: [`/api/users/${vlog.professionalId}`],
  });

  // Format the duration from seconds to minutes:seconds
  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  // Generate placeholder background if no thumbnail is available
  const thumbnailStyle = vlog.thumbnailUrl 
    ? { backgroundImage: `url(${vlog.thumbnailUrl})` } 
    : { 
        background: `linear-gradient(to right, ${category?.color || '#3B82F6'}, ${category?.color ? category.color + '88' : '#60A5FA'})` 
      };

  return (
    <Card className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
      <Link href={`/vlogs/${vlog.id}`}>
        <a className="block">
          <div className="relative">
            <div 
              className="w-full h-48 bg-gray-200 object-cover"
              style={thumbnailStyle}
            >
              {!vlog.thumbnailUrl && (
                <div className="absolute inset-0 flex items-center justify-center text-white">
                  <span className="text-lg font-medium">{vlog.title}</span>
                </div>
              )}
            </div>
            <div className="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center">
              <button className="w-12 h-12 bg-white bg-opacity-80 rounded-full flex items-center justify-center hover:bg-opacity-100 transition">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><polygon points="5 3 19 12 5 21 5 3"/></svg>
              </button>
            </div>
            <span className="absolute bottom-2 right-2 bg-dark bg-opacity-80 text-white text-xs px-2 py-1 rounded">
              {formatDuration(vlog.duration)}
            </span>
            {vlog.isPremium && (
              <span className="absolute top-2 left-2 bg-accent text-white text-xs px-2 py-1 rounded-full">
                Premium
              </span>
            )}
          </div>
        </a>
      </Link>
      
      <CardContent className="p-4">
        <div className="flex items-center mb-3">
          {category && (
            <Badge 
              style={{ backgroundColor: `${category.color}20`, color: category.color }}
              variant="outline"
            >
              {category.name}
            </Badge>
          )}
          <div className="ml-auto flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            <span className="text-sm ml-1">{vlog.rating.toFixed(1)}</span>
          </div>
        </div>
        
        <Link href={`/vlogs/${vlog.id}`}>
          <a className="block">
            <h3 className="font-semibold text-lg mb-2 hover:text-primary transition">{vlog.title}</h3>
          </a>
        </Link>
        
        <div className="flex items-center text-sm text-dark-light mb-3">
          <div className="w-8 h-8 rounded-full bg-gray-300 mr-2 flex items-center justify-center overflow-hidden">
            {professional?.profileImage ? (
              <img 
                src={professional.profileImage} 
                alt={professional.name} 
                className="w-full h-full object-cover"
              />
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-500"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            )}
          </div>
          <span>{professional?.name || `Profissional ${vlog.professionalId}`}</span>
          <span className="mx-2">•</span>
          <span>{vlog.viewCount} visualizações</span>
        </div>
        
        <p className="text-dark-medium text-sm mb-4 line-clamp-2">{vlog.description}</p>
        
        <div className="flex justify-between">
          <Link href={`/vlogs/${vlog.id}`}>
            <a className="text-primary text-sm font-medium hover:text-blue-600">Assistir agora</a>
          </Link>
          <button className="text-dark-light text-sm hover:text-dark-medium">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/></svg>
          </button>
        </div>
      </CardContent>
    </Card>
  );
}
