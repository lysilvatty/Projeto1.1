import { Link } from "wouter";
import { Category } from "@shared/schema";

interface CategoryCardProps {
  category: Category;
}

export default function CategoryCard({ category }: CategoryCardProps) {
  return (
    <Link href={`/explore?category=${category.id}`}>
      <a className="bg-white rounded-lg shadow p-4 text-center hover:shadow-md transition group">
        <div 
          className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3 group-hover:text-white transition"
          style={{ 
            backgroundColor: `${category.color}20`, 
            color: category.color,
          }}
          data-group-hover-style={{ 
            backgroundColor: category.color,
            color: 'white' 
          }}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            {category.icon === 'laptop-code' && (
              <><path d="M20 16V7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v9m16 0H4m16 0 1.28 2.55a1 1 0 0 1-.9 1.45H3.62a1 1 0 0 1-.9-1.45L4 16"/><path d="m13 12 2-2-2-2"/><path d="M9 12 7 10l2-2"/></>
            )}
            {category.icon === 'heartbeat' && (
              <><path d="M20.42 4.58a5.4 5.4 0 0 0-7.65 0l-.77.78-.77-.78a5.4 5.4 0 0 0-7.65 0C1.46 6.7 1.33 10.28 4 13l8 8 8-8c2.67-2.72 2.54-6.3.42-8.42z"/><path d="M3.5 12h6l.5-1 2 4 .5-1h6"/></>
            )}
            {category.icon === 'gavel' && (
              <><path d="m14 13-7.5 7.5c-.83.83-2.17.83-3 0 0 0 0 0 0 0a2.12 2.12 0 0 1 0-3L11 10"/><path d="m16 16 6-6"/><path d="m8 8 6-6"/><path d="m9 7 8 8"/><path d="m21 11-8-8"/></>
            )}
            {category.icon === 'compass' && (
              <><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/></>
            )}
            {category.icon === 'palette' && (
              <><circle cx="13.5" cy="6.5" r="2.5"/><circle cx="19" cy="11" r="2"/><circle cx="19" cy="17" r="2"/><circle cx="13.5" cy="21.5" r="2.5"/><circle cx="8" cy="19" r="2"/><circle cx="5.5" cy="12.5" r="2.5"/><circle cx="8" cy="6" r="2"/></>
            )}
            {category.icon === 'chalkboard-teacher' && (
              <><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><line x1="3" x2="21" y1="9" y2="9"/><path d="M12 14v3"/><path d="m9 15 3-1 3 1"/></>
            )}
            {category.icon === 'bullhorn' && (
              <><path d="M3 14s-.5-2.5 0-5c.5-2.5 4-5 8-5 4 0 5.5 2.5 6 6 .5 3.5-1 7-1 7"/><path d="M10.5 8.5c.8 1.3 1.5 4.5 1.5 6.5"/><path d="M4 21c.5-1.5.5-3 0-4.5"/><path d="M20 2c-1.5 1.5-3 3.5-3 6v1"/><path d="M20 6c-1.5 1-2.5 2.5-3 5"/></>
            )}
            {category.icon === 'chart-line' && (
              <><path d="M21 21H4a2 2 0 0 1-2-2V3"/><path d="m21 16-7-7-4 4-5-5"/></>
            )}
            {category.icon === 'seedling' && (
              <><path d="M12 10a6 6 0 0 0-6-6H3v3a6 6 0 0 0 6 6h3"/><path d="M12 14a6 6 0 0 1 6-6h3v3a6 6 0 0 1-6 6h-3"/><path d="M12 22v-8"/></>
            )}
            {category.icon === 'search-dollar' && (
              <><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/><path d="M11 8v6"/><path d="m8 11 6 0"/></>
            )}
            {!category.icon && (
              <circle cx="12" cy="12" r="10"/>
            )}
          </svg>
        </div>
        <h3 className="font-medium">{category.name}</h3>
        <p className="text-sm text-dark-light mt-1">{category.vlogCount} vlogs</p>
      </a>
    </Link>
  );
}
